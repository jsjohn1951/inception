<?php

/**
 * Title: Hidden Archive
 * Slug: bizboost/hidden-archive
 * Categories: bizboost, page
 * Inserter: no
 */
?>

<!-- wp:query-title {"type":"archive","textAlign":"left"} /-->
<!-- wp:term-description {"textAlign":"center"} /-->

